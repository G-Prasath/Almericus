// ===================== Navbar Start ===========================

document.addEventListener("DOMContentLoaded", function () {
  // Mobile menu functionality
  const mobileMenuButton = document.getElementById("mobile-menu-button");
  const mobileMenu = document.getElementById("mobile-menu");
  const hamburger = document.querySelector(".hamburger");

  mobileMenuButton.addEventListener("click", function () {
    mobileMenu.classList.toggle("show");
    hamburger.classList.toggle("active");
  });

  // Desktop dropdown functionality
  const dropdowns = document.querySelectorAll(".dropdown");
  let activeDropdown = null;
  let timeoutId = null;

  dropdowns.forEach((dropdown) => {
    const button = dropdown.querySelector("button");
    const menu = dropdown.querySelector(".dropdown-menu");
    const arrow = dropdown.querySelector(".dropdown-arrow");

    button.addEventListener("mouseenter", function () {
      if (timeoutId) {
        clearTimeout(timeoutId);
      }

      // Close other dropdowns
      if (activeDropdown && activeDropdown !== dropdown) {
        activeDropdown.querySelector(".dropdown-menu").classList.remove("show");
        activeDropdown.querySelector(".dropdown-arrow").style.transform =
          "rotate(0deg)";
      }

      menu.classList.add("show");
      arrow.style.transform = "rotate(180deg)";
      activeDropdown = dropdown;
    });

    dropdown.addEventListener("mouseleave", function () {
      timeoutId = setTimeout(() => {
        menu.classList.remove("show");
        arrow.style.transform = "rotate(0deg)";
        activeDropdown = null;
      }, 150);
    });

    dropdown.addEventListener("mouseenter", function () {
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
    });
  });

  // Close dropdowns when clicking outside
  document.addEventListener("click", function (event) {
    if (!event.target.closest(".dropdown")) {
      dropdowns.forEach((dropdown) => {
        const menu = dropdown.querySelector(".dropdown-menu");
        const arrow = dropdown.querySelector(".dropdown-arrow");
        menu.classList.remove("show");
        arrow.style.transform = "rotate(0deg)";
      });
      activeDropdown = null;
    }
  });

  // Mobile nested menu functionality
  const mobileDropdowns = document.querySelectorAll(".mobile-dropdown");

  mobileDropdowns.forEach((dropdown) => {
    const button = dropdown.querySelector(".mobile-dropdown-button");
    const menu = dropdown.querySelector(".nested-menu");
    const arrow = button.querySelector("i:last-child");

    button.addEventListener("click", function () {
      menu.classList.toggle("show");
      arrow.style.transform = menu.classList.contains("show")
        ? "rotate(180deg)"
        : "rotate(0deg)";
    });
  });

  // Close mobile menu when clicking on a link
  const mobileLinks = document.querySelectorAll("#mobile-menu a");
  mobileLinks.forEach((link) => {
    link.addEventListener("click", function () {
      mobileMenu.classList.remove("show");
      hamburger.classList.remove("active");
    });
  });

  // Close mobile menu when clicking outside
  document.addEventListener("click", function (event) {
    if (!event.target.closest("nav") && mobileMenu.classList.contains("show")) {
      mobileMenu.classList.remove("show");
      hamburger.classList.remove("active");
    }
  });

  // Smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute("href"));
      if (target) {
        target.scrollIntoView({
          behavior: "smooth",
        });
      }
    });
  });

  //   // Intersection Observer for animations
  //   const observerOptions = {
  //     threshold: 0.1,
  //     rootMargin: "0px 0px -50px 0px",
  //   };

  //   const observer = new IntersectionObserver(function (entries) {
  //     entries.forEach((entry) => {
  //       if (entry.isIntersecting) {
  //         entry.target.style.opacity = "1";
  //         entry.target.style.transform = "translateY(0)";
  //       }
  //     });
  //   }, observerOptions);

  //   // Observe elements for animation
  //   document.querySelectorAll(".card-hover").forEach((card) => {
  //     card.style.opacity = "0";
  //     card.style.transform = "translateY(30px)";
  //     card.style.transition = "opacity 0.6s ease, transform 0.6s ease";
  //     observer.observe(card);
  //   });
});
// ======================== Navbar End ===========================

// =======================  Navbar ative link highlight ==========================
const sections = document.querySelectorAll("section");
const navLinks = document.querySelectorAll(".nav-link");
const navbarHeight = document.querySelector("nav").offsetHeight;

function onScroll() {
  let current = "";

  // find the section currently in view
  sections.forEach((section) => {
    const sectionTop = section.offsetTop - navbarHeight - 1;
    const sectionHeight = section.offsetHeight;

    if (
      window.scrollY >= sectionTop &&
      window.scrollY < sectionTop + sectionHeight
    ) {
      current = section.getAttribute("id");
    }
  });

  // reset all nav links
  navLinks.forEach((link) => {
    link.classList.remove("active-link");
  });

  // add active style to the current one
  if (current) {
    const activeLink = document.querySelector(`.nav-link[href="#${current}"]`);
    if (activeLink) {
      activeLink.classList.add("active-link");
    }
  }
}

window.addEventListener("scroll", onScroll);

// =================== Video ===================

// document.addEventListener("DOMContentLoaded", () => {
//   const playButton = document.getElementById("play-button");
//   const thumbnail = document.getElementById("thumbnail");
//   const videoContainer = document.getElementById("video-cnt");
//   const iframe = videoContainer.querySelector("iframe");

//   playButton.addEventListener("click", () => {
//     thumbnail.classList.add("hidden");
//     videoContainer.classList.remove("hidden");

//     // Trigger autoplay when revealed
//     const src = iframe.getAttribute("src");
//     if (!src.includes("autoplay=1")) {
//       iframe.setAttribute(
//         "src",
//         src + (src.includes("?") ? "&" : "?") + "autoplay=1"
//       );
//     }
//   });
// });
