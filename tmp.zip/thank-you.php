<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Thank You</title>
  <link href='https://fonts.googleapis.com/css?family=Lato:300,400|Montserrat:700' rel='stylesheet' type='text/css'>
  <style>
    @import url(//cdnjs.cloudflare.com/ajax/libs/normalize/3.0.1/normalize.min.css);
    @import url(//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css);
    .redirect-text {
      margin-top: 20px;
      font-size: 18px;
      color: #555;
    }
  </style>
  <link rel="stylesheet" href="https://2-22-4-dot-lead-pages.appspot.com/static/lp918/min/default_thank_you.css">
  <script src="https://2-22-4-dot-lead-pages.appspot.com/static/lp918/min/jquery-1.9.1.min.js"></script>
  <script src="https://2-22-4-dot-lead-pages.appspot.com/static/lp918/min/html5shiv.js"></script>
</head>
<body>
  <header class="site-header" id="header">
    <h1 class="site-header__title" data-lead-id="site-header-title">THANK YOU!</h1>
  </header>

  <div class="main-content">
    <i class="fa fa-check main-content__checkmark" class="bg-red-900" id="checkmark"></i>
    <p class="main-content__body" data-lead-id="main-content-body">
      Thank you for your time and support, I truly appreciate it.
    </p>
    <p class="redirect-text">Redirecting to contact page in <span id="countdown">5</span> seconds...</p>
  </div>

  <script>
    let seconds = 5;
    const countdownEl = document.getElementById("countdown");

    const timer = setInterval(() => {
      seconds--;
      countdownEl.textContent = seconds;
      if (seconds <= 0) {
        clearInterval(timer);
        window.location.href = "index.php";
      }
    }, 1000);
  </script>
</body>
</html>
