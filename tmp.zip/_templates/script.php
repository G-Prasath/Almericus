<!-- ========== Main Script ============  -->
<script defer src="./js/script.js"></script>

<!-- ================== AOS Initialization ================== -->
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    AOS.init({
        once: true,
    });
</script>


